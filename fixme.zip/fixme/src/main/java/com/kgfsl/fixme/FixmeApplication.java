package com.kgfsl.fixme;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;



@SpringBootApplication


public class FixmeApplication {

	public static void main(String[] args) {
		SpringApplication.run(FixmeApplication.class, args);
	}

	
}
